#!/usr/bin/env node
/**
 * configure.mjs — build configurator for wasmpeg.
 *
 * Usage:
 *   node src/cli/configure.mjs             (interactive)
 *   node src/cli/configure.mjs --preset=minimal --target=webgpu --build
 */

import { execSync, spawnSync } from 'child_process';
import { createInterface }     from 'readline';
import { fileURLToPath }       from 'url';
import path                    from 'path';
import fs                      from 'fs';

const ROOT   = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const VENDOR = path.join(ROOT, 'vendor/ffmpeg');
const DIST   = path.join(ROOT, 'dist');

// ── codec presets ─────────────────────────────────────────────────────────────

const PRESETS = {
    // Fast iteration build — smallest output, modern web codecs only.
    minimal: {
        decoders:  ['h264', 'vp8', 'aac', 'opus', 'mp3'],
        encoders:  ['aac', 'mjpeg', 'png'],
        demuxers:  ['mov', 'matroska', 'ogg', 'mp3', 'h264', 'hevc', 'image2', 'image2pipe', 'image_png_pipe'],
        muxers:    ['mp4', 'webm', 'ogg', 'image2', 'null'],
        parsers:   ['h264', 'vp8', 'aac', 'opus', 'png'],
        protocols: ['file'],
        filters:   ['scale', 'crop', 'overlay', 'aresample', 'hstack', 'vstack', 'format'],
        desc: 'Fast dev build — H264/VP8 decode, AAC/MJPEG/PNG encode',
    },

    // wasmpeg — LGPL-2.1-or-later. Safe to embed in commercial products.
    // All codecs are FFmpeg built-ins; no external library required.
    lgpl: {
        gpl: false,
        decoders: [
            // modern web video
            'h264', 'hevc', 'vp8', 'vp9', 'av1',
            // classic / broadcast video
            'mpeg1video', 'mpeg2video', 'mpeg4', 'h263', 'h261',
            // Microsoft
            'msmpeg4v1', 'msmpeg4v2', 'msmpeg4v3', 'wmv1', 'wmv2', 'wmv3', 'vc1', 'mss2',
            // Apple / QuickTime
            'prores', 'qtrle', 'svq1', 'svq3', 'qdm2',
            // professional / broadcast
            'dnxhd', 'mjpeg', 'mjpegb', 'cfhd',
            // lossless / archival
            'huffyuv', 'ffv1', 'ffvhuff', 'utvideo', 'magicyuv', 'lagarith', 'hap',
            // Bink (game video/audio)
            'bink', 'binkaudio_dct', 'binkaudio_rdft',
            // legacy / game
            'theora', 'vp3', 'vp6', 'vp6a', 'vp6f', 'vp7', 'rv10', 'rv20', 'rv30', 'rv40',
            'flashsv', 'flashsv2', 'cinepak', 'msvideo1',
            'fraps', 'cdxl', 'flic', 'zmbv', 'cllc', 'hq_hqa', 'hqx', 'speedhq',
            // Intel Indeo, LOCO, Microsoft RLE, DV — legacy AVI/MOV video
            'indeo2', 'indeo3', 'indeo4', 'indeo5', 'loco', 'msrle', 'dvvideo',
            // screen-capture / lossless-ish AVI/MOV codecs
            'dxtory', 'fic', 'fmvc', 'frwu', 'mszh', 'zlib', 'lscr', 'rscc',
            'tscc', 'tscc2', 'vble', 'zerocodec', 'mwsc', 'screenpresso',
            'g2meet', 'mss1', 'lead', 'dxv', 'aic',
            // legacy / game / vendor video codecs
            'aura', 'aura2', 'cljr', 'cyuv', 'ulti', 'vcr1', 'xl', 'wnv1', 'vqc',
            'truemotion1', 'truemotion2', 'truemotion2rt', 'xan_wc3', 'xan_wc4',
            'vp4', 'vp5', 'mimic', 'mdec', 'eamad', 'eatgq', 'sgirle',
            'nuv', 'rv60', 'thp', 'txd', 'mts2', 'avui', 'avrn', 'cavs',
            'roqvideo', 'dirac',
            // more legacy / game / multimedia video
            'dfa', 'brender_pix', 'paf_video', 'vmdvideo', 'fits', 'fourxm',
            'jv', 'vb', 'ansi', 'dxa', 'aasc', 'qpeg', 'sp5x', 'motionpixels',
            'mvc1', 'mvc2', 'rl2', 'c93', 'cdgraphics', 'bethsoftvid', 'bfi',
            'tmv', 'tdsc', 'cscd', 'kmvc', 'qdraw', 'smc', 'rpza', 'pixlet',
            'idcin', 'dsicinvideo', 'smacker', 'bmv_video',
            // raw packed-pixel formats (.avi / .mov)
            'r210', 'v210', 'v410', 'r10k',
            // images
            'png', 'apng', 'gif', 'bmp', 'tiff', 'webp', 'targa', 'dpx', 'xbm',
            'sunrast', 'xface',
            'jpeg2000', 'jpegls', 'exr', 'psd',
            // modern audio
            'aac', 'aac_latm', 'opus', 'mp3', 'mp2', 'mp1', 'vorbis', 'flac',
            // surround / professional audio
            'ac3', 'ac3_fixed', 'eac3', 'dca', 'truehd', 'mlp',
            // lossless audio
            'alac', 'wavpack', 'ape', 'tta', 'shorten',
            // Microsoft audio
            'wmav1', 'wmav2', 'wmapro', 'wmalossless', 'wmavoice',
            // PCM — all signed/unsigned/float variants
            'pcm_s8', 'pcm_u8',
            'pcm_s16le', 'pcm_s16be', 'pcm_u16le', 'pcm_u16be',
            'pcm_s24le', 'pcm_s24be', 'pcm_u24le', 'pcm_u24be',
            'pcm_s32le', 'pcm_s32be', 'pcm_u32le', 'pcm_u32be',
            'pcm_f32le', 'pcm_f32be', 'pcm_f64le', 'pcm_f64be',
            'pcm_mulaw', 'pcm_alaw', 'pcm_dvd', 'pcm_bluray', 'pcm_vidc',
            // ADPCM — common
            'adpcm_ms', 'adpcm_ima_wav', 'adpcm_ima_qt',
            'adpcm_swf', 'adpcm_yamaha', 'adpcm_thp',
            'adpcm_g726', 'adpcm_g726le', 'adpcm_g722',
            // ADPCM — game / EA variants
            'adpcm_4xm', 'adpcm_afc', 'adpcm_dtk',
            'adpcm_ea', 'adpcm_ea_maxis_xa', 'adpcm_ea_r1', 'adpcm_ea_r2', 'adpcm_ea_r3',
            'adpcm_ima_amv', 'adpcm_ima_apc', 'adpcm_ima_dk3', 'adpcm_ima_dk4',
            'adpcm_ima_ea_eacs', 'adpcm_ima_ea_sead',
            'adpcm_ima_iss', 'adpcm_ima_oki', 'adpcm_ima_rad', 'adpcm_ima_smjpeg', 'adpcm_ima_ws',
            'adpcm_argo', 'adpcm_sanyo', 'adpcm_vima', 'adpcm_xa',
            // ADPCM — creative / SB
            'adpcm_sbpro_2', 'adpcm_sbpro_3', 'adpcm_sbpro_4',
            // DPCM
            'roq_dpcm', 'interplay_dpcm', 'sol_dpcm', 'xan_dpcm',
            // other audio
            'speex', 'nellymoser', 'amrnb', 'amrwb',
            'g722', 'g723_1', 'g726', 'gsm', 'gsm_ms',
            'atrac1', 'atrac3', 'atrac3p', 'sipr',
            // legacy / niche decoders needed by FATE
            'imc', 'truespeech', 'cook', 'ra_144', 'ra_288',
            'qcelp', 'g728', 'twinvq', 'dolby_e', 'dst',
            'mpc7', 'mpc8',
            // Apple MACE (QuickTime legacy audio)
            'mace3', 'mace6',
            // Escape codecs (RPL/ARMovie containers)
            'escape124', 'escape130',
            // game / multimedia + lossless audio
            'qoa', 'tak', 'smackaud', 'paf_audio', 'vmdaudio', 'bmv_audio',
            'dsicinaudio', 'dss_sp', 'msnsiren', 'dsd_lsbf', 'dsd_msbf',
        ],
        encoders: [
            // video
            'mjpeg', 'png', 'gif', 'bmp', 'tiff', 'targa', 'dpx',
            'huffyuv', 'ffv1',
            // audio
            'aac', 'opus', 'flac', 'mp2', 'wavpack',
            'wmav1', 'wmav2', 'eac3', 'ac3_fixed',
            'pcm_s16le', 'pcm_s24le', 'pcm_f32le', 'pcm_mulaw', 'pcm_alaw',
            'adpcm_ms', 'adpcm_ima_wav',
        ],
        demuxers: [
            // major containers
            'mov', 'matroska', 'avi', 'ogg', 'asf', 'flv', 'rm', 'mxf', 'dv',
            // audio containers
            'mp3', 'wav', 'flac', 'aac', 'ac3', 'dts', 'truehd', 'mlp',
            'amr', 'g722', 'g726', 'gsm',
            // lossless audio containers (decoders were already in; demuxers were missing)
            'wv', 'ape',
            // Bink
            'bink', 'binka',
            // CDXL (Amiga)
            'cdxl',
            // g723.1 audio
            'g723_1',
            // raw bitstreams — note: vp8/vp9 raw uses ivf, mpeg PS = mpegps not mpeg
            'h264', 'hevc', 'h263', 'h261', 'av1', 'ivf',
            'm4v',
            'mpegps', 'mpegvideo', 'mpegts', 'rawvideo',
            // raw VC-1 bitstream (.vc1) and VC-1 test format (.rcv)
            'vc1', 'vc1t',
            // raw DNxHD/DNxHR bitstream (.dnxhr)
            'dnxhd',
            // containers for the legacy/game video decoders above
            'nuv', 'thp', 'txd', 'mv', 'cavsvideo', 'apng', 'dirac',
            'dfa', 'paf', 'vmd', 'fits', 'qoa', 'bmv', 'dsicin', 'smacker',
            'jv', 'siff', 'ipmovie', 'dss', 'tak', 'rl2', 'c93', 'cdg',
            'bethsoftvid', 'bfi', 'tmv', 'mm', 'idcin', 'yop', 'ea_cdata', 'flic',
            // EA (Electronic Arts) container — used for VP6 in ea-vp6 test files
            'ea',
            // E-AC-3 bare stream
            'eac3',
            // game / multimedia containers for ADPCM/DPCM FATE tests
            'fourxm', 'ast', 'voc', 'amv', 'apc',
            'wsvqa', 'iss', 'rsd', 'smjpeg', 'smush',
            'roq', 'mve', 'sol', 'xa', 'str',
            'dxa', 'kvag', 'apm', 'alp', 'pp_bnk',
            'argo_asf',
            // additional containers for FATE niche audio tests
            'aea', 'brstm', 'bfstm', 'dsf', 'mpc', 'qcp', 'tta', 'vqf', 'xwma',
            'shorten', 'g728', 's337m',
            // Sony OMA/AA3 (ATRAC3/ATRAC3+ in OpenMG containers)
            'oma',
            // ARMovie/RPL container (Escape 124/130 video codecs)
            'rpl',
            // image pipes — one per format, needed for auto-detection of bare image files
            'image2', 'image2pipe',
            'image_png_pipe', 'image_bmp_pipe', 'image_gif_pipe',
            'image_tiff_pipe', 'image_webp_pipe',
            'image_j2k_pipe', 'image_jpeg_pipe', 'image_jpegls_pipe',
            'image_exr_pipe', 'image_psd_pipe',
            'image_dpx_pipe',
            'image_xbm_pipe', 'image_sunrast_pipe', 'image_xface_pipe',
            // PCM raw — covers all signed/unsigned/float variants used in FATE
            'pcm_s8', 'pcm_u8',
            'pcm_s16le', 'pcm_s16be', 'pcm_u16le', 'pcm_u16be',
            'pcm_s24le', 'pcm_s24be', 'pcm_u24le', 'pcm_u24be',
            'pcm_s32le', 'pcm_s32be', 'pcm_u32le', 'pcm_u32be',
            'pcm_f32le', 'pcm_f32be', 'pcm_f64le', 'pcm_f64be',
            'pcm_mulaw', 'pcm_alaw', 'pcm_vidc',
            // other
            'concat', 'wtv',
        ],
        muxers: [
            'mp4', 'webm', 'ogg', 'matroska', 'avi', 'flv', 'asf',
            'mpegts', 'wav', 'flac', 'ac3', 'adts', 'opus', 'truehd',
            'image2', 'image2pipe', 'mjpeg', 'apng', 'gif', 'webp', 'null',
            'pcm_s16le', 'pcm_f32le', 'pcm_mulaw', 'pcm_alaw',
        ],
        parsers: [
            'h264', 'hevc', 'vp8', 'vp9', 'av1',
            'mpeg4video', 'mpegvideo', 'h263', 'vc1', 'dvbsub', 'dvdsub',
            'aac', 'aac_latm', 'ac3', 'dca', 'flac', 'opus',
            'mpegaudio', 'png', 'gif', 'bmp', 'cavsvideo', 'vp3', 'dirac',
        ],
        protocols: ['file'],
        filters: [
            'scale', 'crop', 'overlay', 'aresample',
            'hflip', 'vflip', 'hstack', 'vstack', 'format', 'transpose', 'rotate',
            'pad', 'trim', 'setpts', 'fps', 'split', 'colorspace',
            'eq', 'hue', 'curves', 'colorbalance', 'colorchannelmixer',
            'noise', 'unsharp', 'boxblur', 'gblur',
            'yadif', 'bwdif', 'deinterlace',
            'volume', 'atrim', 'asetpts', 'amerge', 'amix', 'aecho',
            'highpass', 'lowpass', 'equalizer',
            'concat', 'null', 'anull',
        ],
        desc: 'wasmpeg — comprehensive LGPL build, safe for commercial use',
    },

    // wasmpeg-full — GPL-2.0-or-later.
    // Adds H.264 and H.265 encoding via libx264/libx265.
    // Requires external libs; see docs/build/configuration.md#external-libraries.
    // NOTE: linking this binary into a closed-source product requires GPL compliance.
    gpl: {
        gpl: true,
        // inherits all lgpl codecs — extended below after PRESETS is defined
        decoders: [],
        encoders: [],
        demuxers: [],
        muxers:   [],
        parsers:  [],
        protocols: ['file'],
        filters:  [],
        extraFlags: [
            '--enable-gpl',
            // external libs — uncomment once cross-compiled (see docs/build/from-source.md)
            // '--enable-libx264',
            // '--enable-libx265',
        ],
        extraEncoders: [
            // 'libx264',
            // 'libx265',
        ],
        desc: 'wasmpeg-full — GPL build, adds H.264/H.265 encode (libx264/libx265)',
    },

    // Fast iteration — keep for dev speed
    standard: {
        decoders:  ['h264', 'hevc', 'vp8', 'vp9', 'av1', 'aac', 'opus',
                    'mp3', 'mp2', 'vorbis', 'flac', 'ac3', 'eac3', 'dca', 'truehd',
                    'alac', 'wavpack', 'pcm_s16le', 'pcm_s24le', 'pcm_f32le', 'pcm_mulaw', 'pcm_alaw',
                    'adpcm_ms', 'adpcm_ima_wav', 'adpcm_ima_qt',
                    'png', 'mjpeg', 'mjpegb', 'gif', 'bmp', 'tiff', 'webp',
                    'mpeg1video', 'mpeg2video', 'mpeg4', 'h263',
                    'wmv1', 'wmv2', 'wmv3', 'vc1', 'msmpeg4v3',
                    'prores', 'dnxhd', 'huffyuv', 'ffv1',
                    'theora', 'vp3', 'vp6f', 'vp7',
                    'wmav1', 'wmav2', 'ape',
                    'amrnb', 'amrwb', 'gsm', 'gsm_ms', 'speex'],
        encoders:  ['aac', 'opus', 'flac', 'mjpeg', 'png', 'gif'],
        demuxers:  ['mov', 'matroska', 'avi', 'ogg', 'asf', 'flv', 'rm',
                    'mp3', 'wav', 'flac', 'aac', 'ac3', 'dts', 'truehd',
                    'amr', 'gsm',
                    'h264', 'hevc', 'vp8', 'vp9', 'av1',
                    'mpeg', 'mpegvideo', 'mpegts', 'm4v',
                    'mjpeg', 'gif', 'bmp', 'tiff',
                    'image2', 'image2pipe', 'image_png_pipe',
                    'concat', 'flac', 'pcm_s16le', 'pcm_mulaw', 'pcm_alaw'],
        muxers:    ['mp4', 'webm', 'ogg', 'image2', 'wav', 'null', 'flac'],
        parsers:   ['h264', 'hevc', 'vp8', 'vp9', 'av1', 'aac', 'opus', 'png',
                    'ac3', 'dca', 'flac', 'mpegaudio', 'mpeg4video'],
        protocols: ['file'],
        filters:   ['scale', 'crop', 'overlay', 'aresample', 'hstack', 'vstack', 'format',
                    'transpose', 'rotate', 'pad', 'trim', 'setpts', 'fps', 'split', 'colorspace'],
        desc: 'Standard dev build — broad decode, common filters',
    },

    // Royalty-free only: nothing here is encumbered by the MPEG-LA/Access
    // Advance patent pools, so this build can ship where H.264/HEVC/AAC and the
    // MPEG-family codecs are a licensing problem. Deliberately excludes h264,
    // hevc, aac, mpeg1/2/4, h263, vc1, wmv, dts and ac3.
    free: {
        gpl: false,
        decoders:  ['vp8', 'vp9', 'av1', 'theora', 'vp3', 'vp6', 'vp6a', 'vp6f',
                    'opus', 'vorbis', 'flac', 'speex',
                    'pcm_s16le', 'pcm_s16be', 'pcm_u8', 'pcm_s24le', 'pcm_s32le',
                    'pcm_f32le', 'pcm_f64le', 'pcm_mulaw', 'pcm_alaw',
                    'png', 'apng', 'gif', 'bmp', 'tiff', 'webp', 'targa', 'dpx',
                    'ffv1', 'huffyuv', 'ffvhuff', 'utvideo', 'magicyuv', 'qoa'],
        encoders:  ['vorbis', 'opus', 'flac', 'png', 'gif', 'bmp', 'tiff',
                    'ffv1', 'huffyuv',
                    'pcm_s16le', 'pcm_f32le'],
        demuxers:  ['matroska', 'ogg', 'wav', 'flac', 'ivf', 'av1', 'rawvideo',
                    'apng', 'qoa', 'image2', 'image2pipe',
                    'image_png_pipe', 'image_bmp_pipe', 'image_gif_pipe',
                    'image_tiff_pipe', 'image_webp_pipe'],
        muxers:    ['webm', 'ogg', 'matroska', 'wav', 'flac', 'image2',
                    'image2pipe', 'apng', 'gif', 'webp', 'null'],
        parsers:   ['vp8', 'vp9', 'av1', 'opus', 'flac', 'vp3', 'png', 'gif', 'bmp'],
        protocols: ['file'],
        filters:   ['scale', 'crop', 'overlay', 'aresample', 'hflip', 'vflip',
                    'hstack', 'vstack', 'format', 'transpose', 'pad', 'trim',
                    'setpts', 'fps', 'split', 'null', 'anull'],
        desc: 'Royalty-free codecs only — VP8/VP9/AV1/Theora, Opus/Vorbis/FLAC, lossless + images',
    },
};

// GPL preset inherits everything from lgpl and extends it
Object.assign(PRESETS.gpl, {
    decoders:  [...PRESETS.lgpl.decoders],
    encoders:  [...PRESETS.lgpl.encoders, ...PRESETS.gpl.extraEncoders],
    demuxers:  [...PRESETS.lgpl.demuxers],
    muxers:    [...PRESETS.lgpl.muxers],
    parsers:   [...PRESETS.lgpl.parsers],
    filters:   [...PRESETS.lgpl.filters],
});

// ── arg parsing ───────────────────────────────────────────────────────────────

const args = Object.fromEntries(
    process.argv.slice(2)
        .filter(a => a.startsWith('--'))
        .map(a => { const [k, v] = a.slice(2).split('='); return [k, v ?? true]; })
);

// ── readline helper ───────────────────────────────────────────────────────────

async function ask(rl, question, fallback) {
    return new Promise(resolve => {
        rl.question(`${question} [${fallback}]: `, ans => {
            resolve(ans.trim() || fallback);
        });
    });
}

// ── generate configure flags ──────────────────────────────────────────────────

function buildFlags(preset, webgpu) {
    const p = PRESETS[preset];
    const flags = [
        '--target-os=none', '--arch=x86_32', '--enable-cross-compile',
        '--disable-x86asm', '--disable-inline-asm', '--disable-stripping',
        '--disable-ffplay', '--disable-ffprobe', '--disable-doc',
        '--disable-debug', '--disable-runtime-cpudetect', '--disable-autodetect',
        '--enable-small', '--disable-pthreads', '--disable-network',
        '--disable-everything',
        '--enable-zlib',
        '--enable-avcodec', '--enable-avformat', '--enable-avfilter',
        '--enable-avutil', '--enable-swscale', '--enable-swresample',
        ...(p.extraFlags ?? []),
        ...p.decoders.map(c => `--enable-decoder=${c}`),
        ...p.encoders.map(c => `--enable-encoder=${c}`),
        ...p.demuxers.map(c => `--enable-demuxer=${c}`),
        ...p.muxers.map(c  => `--enable-muxer=${c}`),
        ...p.parsers.map(c => `--enable-parser=${c}`),
        ...p.protocols.map(x => `--enable-protocol=${x}`),
        ...p.filters.map(f => `--enable-filter=${f}`),
    ];
    if (webgpu) {
        flags.push('--enable-webgpu', '--enable-filter=scale_webgpu');
    }
    return flags;
}

// ── main ──────────────────────────────────────────────────────────────────────

async function main() {
    console.log('\nwasmpeg build configurator');
    console.log('─'.repeat(40));

    let preset  = args.preset;
    let target  = args.target;
    let doBuild = args.build === true;

    if (!preset || !target) {
        const rl = createInterface({ input: process.stdin, output: process.stdout });

        if (!preset) {
            console.log('\nPresets:');
            for (const [name, p] of Object.entries(PRESETS))
                console.log(`  ${name.padEnd(10)} ${p.desc}`);
            preset = await ask(rl, '\nPreset', 'minimal');
            if (!PRESETS[preset]) { console.error(`Unknown preset: ${preset}`); process.exit(1); }
        }

        if (!target) {
            target = await ask(rl, 'Target  (cpu / webgpu / both)', 'both');
        }

        const confirm = await ask(rl, '\nRun configure + build now? (y/n)', 'n');
        doBuild = confirm.toLowerCase() === 'y';
        rl.close();
    }

    const targets = target === 'both' ? ['cpu', 'webgpu'] : [target];
    const p = PRESETS[preset];

    console.log('\nWill build:');
    console.log(`  preset:   ${preset}`);
    console.log(`  targets:  ${targets.join(', ')}`);
    console.log(`  decoders: ${p.decoders.join(', ')}`);
    console.log(`  encoders: ${p.encoders.join(', ')}`);
    console.log(`  filters:  ${p.filters.concat(targets.includes('webgpu') ? ['scale_webgpu'] : []).join(', ')}`);

    for (const t of targets) {
        const webgpu     = t === 'webgpu';
        const buildSuffix = p.gpl ? '-gpl' : '';
        const prefix      = path.join(ROOT, `build${buildSuffix}-${t}`);
        const flags      = buildFlags(preset, webgpu);
        const scriptName = `configure-${t}.sh`;
        const script     = path.join(ROOT, scriptName);

        // Both targets get simd128: the webgpu build still runs swscale and every
        // decoder on the CPU, and a GPU-vs-CPU comparison inside one binary is
        // meaningless if only one side is vectorised.
        // --use-port=zlib, not a bare -lz: a bare -lz only linked locally
        // because an earlier build's --use-port=zlib had already populated
        // this machine's emscripten cache with a prebuilt libz.a. On a clean
        // emsdk install there's nothing for -lz to find, and configure's own
        // C-compiler sanity check (a trivial main(), linked with these exact
        // flags) fails before it gets to probing a single codec. Needed on
        // both cflags (zlib.h) and ldflags (libz.a).
        const extraCflags  = webgpu
            ? '-O3 -msimd128 --use-port=emdawnwebgpu --use-port=zlib'
            : '-O3 -msimd128 --use-port=zlib';
        // emdawnwebgpu is a C++ port — even configure's own trivial C sanity-check
        // link fails without DEFAULT_TO_CXX once the port is on the link line.
        const extraLdflags = webgpu
            ? '-O3 --use-port=zlib --use-port=emdawnwebgpu -s ASYNCIFY -s INITIAL_MEMORY=67108864 -s DEFAULT_TO_CXX=1'
            : '-O3 --use-port=zlib';

        const content = [
            '#!/bin/bash',
            `# Generated by src/cli/configure.mjs — ${new Date().toISOString()}`,
            'set -e',
            '',
            `cd "${VENDOR}"`,
            `emconfigure ./configure \\`,
            `    ${flags.join(' \\\n    ')} \\`,
            `    --prefix=${prefix} \\`,
            '    --cc=emcc --cxx=em++ --ar=emar --ranlib=emranlib \\',
            '    --disable-shared --enable-static \\',
            `    --extra-cflags="${extraCflags}" \\`,
            '    --extra-cxxflags="-O3" \\',
            `    --extra-ldflags="${extraLdflags}"`,
            '',
        ].join('\n');

        fs.writeFileSync(script, content, { mode: 0o755 });
        console.log(`\n  wrote ${scriptName}`);

        if (doBuild) {
            console.log(`\n  configuring ${t}...`);
            const nproc = process.platform === 'darwin'
                ? execSync('sysctl -n hw.ncpu').toString().trim()
                : execSync('nproc').toString().trim();

            const r = spawnSync('bash', ['-c',
                `bash "${script}" && cd "${VENDOR}" && emmake make -j${nproc} install`],
                { stdio: 'inherit' });
            if (r.status !== 0) { console.error(`configure-${t} failed`); process.exit(1); }
            console.log(`  ${t} libraries built.`);
        }
    }

    if (!doBuild) {
        console.log('\nTo build manually, run:');
        for (const t of targets)
            console.log(`  bash configure-${t}.sh && cd vendor/ffmpeg && emmake make install`);
    }

    console.log('');
}

main().catch(e => { console.error(e); process.exit(1); });
